// main.c -- Defines the C-code kernel entry point, calls initialisation routines.
//           Made for JamesM's tutorials <www.jamesmolloy.co.uk>

#include "monitor.h"
#include "descriptor_tables.h"
#include "timer.h"
#include "paging.h"
#include "multiboot.h"
#include "fs.h"
#include "initrd.h"
#include "task.h"

extern u32int placement_address;
u32int initial_esp;

static void process_one(registers_t reg){
	int flags = 1;
	int fd;
	char buf[256];
	monitor_write("Opening Test.txt\n");
	if((fd = open("test.txt", flags)) > 0){
	        monitor_write("File test.txt opened!\n");
	}
	monitor_write("Reading the first file...\n");
	read(fd, buf, 256, 0);
	monitor_write("\t");
	monitor_write(buf);
	monitor_write("\n");
	monitor_write("Closing the first file...\n");
	close(fd);
}

void init_process_one(){
  register_interrupt_handler(0x0, &process_one);
}

static void process_two(registers_t reg){
  int flags = 1;
  int fd;
  char buf[256];
  char* str = "New text for test2.txt";
  monitor_write("Opening test2.txt\n");
  if((fd = open("test2.txt", flags))>0){
    monitor_write("File test2.txt opened!\n");
  }
  monitor_write("Reading the second file...\n");
  read(fd, buf, 256,0);
  monitor_write("\t");
  monitor_write(buf);
  monitor_write("\n");
  monitor_write("Writing to second file...\n");
  write(fd,str,256,0);
  monitor_write("Reading the second file...\n");
  read(fd, buf, 256,0);
  monitor_write("\t");
  monitor_write(buf);
  monitor_write("\n");
  monitor_write("Closing the second file...\n");
  close(fd);
}

void init_process_two(){
  register_interrupt_handler(0x1, &process_two);
}

#include "monitor.h"
#include "descriptor_tables.h"
#include "timer.h"
#include "paging.h"
#include "multiboot.h"
#include "common.h"
#include "vfs.h"
#include "fs.h"

int main(struct multiboot *mboot_ptr, u32int initial_stack)
{
	init_descriptor_tables();
	monitor_clear();
	init_vfs(mboot_ptr);
  init_process_one();
  init_process_two();
  monitor_write("Calling first process...\n");
  asm volatile("int $0x0");
  monitor_write("\nCalling second process...\n");
  asm volatile("int $0x1");
	monitor_write("\nDone!");
	return 0;
}
//**/
