#!/bin/bash

#запускаем в эмуляторе qemu

qemu-system-i386 -hda hdd.img -m 640

